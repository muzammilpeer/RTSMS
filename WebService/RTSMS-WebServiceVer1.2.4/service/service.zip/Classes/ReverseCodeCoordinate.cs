﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RTSMSWebService.Classes
{
    public class ReverseCodeCoordinate
    {
        public string locationname { get; set; }
    }

}